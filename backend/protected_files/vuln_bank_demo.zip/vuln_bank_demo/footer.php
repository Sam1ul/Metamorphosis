  </div> <!-- col -->
</div> <!-- row -->
</div> <!-- container -->
<footer class="mt-5 py-4 bg-white shadow-sm">
  <div class="container text-center small text-muted">
    VulnBank — educational demo. Remove after use. &middot; Do not expose to the internet.
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
